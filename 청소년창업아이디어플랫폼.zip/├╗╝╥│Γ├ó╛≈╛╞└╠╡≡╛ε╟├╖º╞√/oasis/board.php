<?php
session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Oasis Hackthon</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="oasis.css" rel="stylesheet">
  </head>
  <body>
    
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
            <li class="nav-item">
                <a class="nav-link" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/main.php">Main</a>
            </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/board.php">아이디어</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/notice.php">공고정보</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/commu.php">소통</a>
          </li>
        </ul>
        <form class="d-flex">
          <button class="logout-button"type="button" onclick="location.href='index.php'">Logout</button>
        </form>
      </div>
    </div>
  </nav>
</header>

 

<main>
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
        <img src="assets/img/002.png">
        <rect width="100%" height="100%" fill="#777"/>
        </svg>
      </div>
    </div>
      <div style="padding-top:20px">
        <h3 class="centered" >아이디어 공유 게시판</h3></div>
          <div style='width:80px;float: right;'>
            <button class="write-button" type="button" class="btn btn-warning" onclick="location.href='write.php'">Write</button> 
          </div>
    <hr size="10">
  </div>

  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->
        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <?php
                        $conn = mysqli_connect('unilab.kro.kr', 'user', 'password', 'post', 7676);
                        $sql = "SELECT * FROM post_table";
                        $result = mysqli_query($conn, $sql);
                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image-->
                            <img class="card-img-top" src="<?php echo $row["img"]?>" alt="..." />
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- idea title-->
                                    <h5 class="fw-bolder">
                                      <a href="post.php?id=<?php echo $row['post_id']?>">
                                        <?php
                                        echo $row["post_title"];
                                        $_SESSION['id'] = $row["post_id"];
                                        ?>
                                      </a>
                                    </h5>
                                    <!-- idea name-->
                                    <p><?php echo $row["author"];?></p>
                                    <p><?php echo $row["post_date"];?></p>
                                    <p><?php echo $row["oneline"];?></p>
                                    <p><?php echo $row["age"];?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                            }
                        } else {
                            mysqli_close($conn);
                        }
                    ?>
                        
        </section>
    <!-- /.container -->


  <!-- FOOTER -->
  <footer class="container">
    <p class="float-end"><a href="#">Back to top</a></p>
    <p>&copy; 2017–2021 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>
