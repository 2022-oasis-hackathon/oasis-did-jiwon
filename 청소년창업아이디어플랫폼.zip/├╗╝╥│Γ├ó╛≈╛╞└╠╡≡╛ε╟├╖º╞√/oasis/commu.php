<?php
session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Oasis Hackthon</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="oasis.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
</head>

<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand menu-icon" href="#"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
        <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/main.php">Main</a>
                </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/board.php">아이디어</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/notice.php">공고정보</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/commu.php">소통</a>
          </li>
        </ul>
        <form class="d-flex">
          <button class="logout-button"type="button" onclick="location.href='index.php'">Logout</button>
        </form>
      </div>
    </div>
  </nav>
</header>

 

<main>

<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
            <img src="assets/img/004.png">
            <rect width="100%" height="100%" fill="#777"/>
            </svg>
        </div>
    </div>
</div>

  <h3 class="centered">소통해요~</h3>
  <div style='width:80px;float: right;'>
  <button class="write-button"type="button" onclick="location.href='write.html'">Write</button>
    </div>
    <hr size="10">

<div style="padding-top: 40px;">
<table class= "sub_news"  cellspacing="0" summary="게시판의 글제목 리스트">
    <caption>게시판 리스트</caption>
    <colgroup>
    <col>
    <col width="110">
    <col width="100">
    <col width="80">
    </colgroup>   
    <thead>
    <tr>
    <th scope="col">제목</th>
    <th scope="col">글쓴이</th>  
    <th scope="col">날짜</th>  
    <th scope="col">조회수</th>      
    </tr>        
    </thead> 
    <tbody>
       <tr>
        <td class="title">
        <a href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/sothong.html" style="padding-left: 8px;">bitnami사용법</a>
        </td>
        <td class="name">운암 양씨</td>
        <td class="date">2022/07/21</td>
        <td class ="hit">24</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">bitnami설치법</a>
        </td>
        <td class="name">운암 구씨</td>
        <td class="date">2022/08/21</td>
        <td class ="hit">214</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">bitnami오류</a>
        </td>
        <td class="name">운암 애씨</td>
        <td class="date">2021/07/21</td>
        <td class ="hit">4224</td>
       </tr><tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">배가아파요</a>
        </td>
        <td class="name">운암 배씨</td>
        <td class="date">2020/07/21</td>
        <td class ="hit">241</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">코드수정할때 조심해야할점</a>
        </td>
        <td class="name">신용 자씨</td>
        <td class="date">2022/04/21</td>
        <td class ="hit">32</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">JS문법</a>
        </td>
        <td class="name">신용 지씨</td>
        <td class="date">2022/02/21</td>
        <td class ="hit">48</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">해커톤 꿀팁</a>
        </td>
        <td class="name">신용 박씨</td>
        <td class="date">2022/01/31</td>
        <td class ="hit">32</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">class 선택자</a>
        </td>
        <td class="name">신용 김씨</td>
        <td class="date">2022/01/26</td>
        <td class ="hit">22</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">태그쓸때 주의할점</a>
        </td>
        <td class="name">신용 우씨</td>
        <td class="date">2022/01/25</td>
        <td class ="hit">35</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">css사용법</a>
        </td>
        <td class="name">신용 기씨</td>
        <td class="date">2022/01/24</td>
        <td class ="hit">34</td>
       </tr>
       <tr>
        <td class="title">
        <a href="#" style="padding-left: 8px;">html사용법</a>
        </td>
        <td class="name">신용비씨</td>
        <td class="date">2022/01/23</td>
        <td class ="hit">33</td>
       </tr>

    </tbody>
</table>
</div>
  <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
    </main>
    
</html>