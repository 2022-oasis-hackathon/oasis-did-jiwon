<?php
//DB접속
$conn = mysqli_connect('unilab.kro.kr', 'user', 'password', 'post', 7676);
?>
