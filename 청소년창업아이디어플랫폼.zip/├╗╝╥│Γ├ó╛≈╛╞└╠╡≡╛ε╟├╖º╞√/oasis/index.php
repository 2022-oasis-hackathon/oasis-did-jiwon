<!Doctype html>
<html>

  <head>
    <meta charset="utf-8">
    <title>MY REPORT</title>
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="oasis.css" rel="stylesheet">
    
    <style media="screen">
      form.container{
        width: 70%;
  height: 70%;
  margin: 40px auto;
  background: none;
      }
      .outer {
  display: table;
  width: 100%;
  height: 100%;
}
.inner {
  display: table-cell;
  vertical-align: middle;
  text-align: center;
}
.centered {
  position: relative;
  display: inline-block;

  width: 50%;
  padding: 1em;
  background: white;
  color: blue;
}

h1{
  font-size: 700%;
}
input[type="submit"]{
  background-color: #024152;
  border: none;
  color: white;
  padding: 8px 16px;
  text-decoration: none;
  margin: 30px 2px;
  cursor: pointer;
  font-size: 25px;
}
    </style>
  </head>
  <body>
    <form class="container" action="login.php" method="post">

      <div class="outer">
        <div class="inner">
          <div class="centered">
            <img src="assets/img/wazak2.png">
            <h5 class="login-text-color">청소년 취창업을 위한 플랫폼</h5>
            <div class="login-color">
            <label for="email" class="form-label">Phone Number</label>
            <input type="text" name="user_id" value="" autocomplete="off" >
              <div class="invalid-feedback">
                Put down the number
              </div>
             
            <div class="login-submit">
            <input type="submit" name="login" value="접속" >
          </div>
          </div>
        </div>

      </div>

    </form>
  </body>
</html>