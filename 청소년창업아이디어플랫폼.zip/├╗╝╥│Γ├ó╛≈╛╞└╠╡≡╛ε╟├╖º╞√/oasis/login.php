<?php
session_cache_limiter('');
session_start();
//DB접속을 위해 불러옴
require_once('db.php');
//사용자가 유저리스트에 있는지 체크
$stid =mysqli_real_escape_string($conn, $_POST['user_id']);
$sql = "SELECT * FROM `user_table` WHERE `user_id` = '{$stid}'";
$LoginResult = mysqli_query($conn, $sql);
//존재하나 안하나 조건문사용해서 알아보자
if($LoginResult->num_rows > 0){
//존재한다면 유저리스트 테이블에서 id값을 알아낸다.
$row = mysqli_fetch_assoc($LoginResult);
$UserID = $row['user_id'];
}else {
  //존재하지 않는다면 학번을 유저리스트에 추가 후 id를 알아낸다.
  $sql = "INSERT INTO user_table (user_id, user_name) VALUES(NULL, '{$stid}');";
  $LoginResult = mysqli_query($conn, $sql);
  $UserID = mysqli_insert_id($conn);
}

//세션에 아이디값을 넣어보자
$_SESSION['id'] = $UserID;
//사용자를 노트로 보낸다
header('Location: main.php');

?>
