
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Oasis Hackthon</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="oasis.css" rel="stylesheet">
  </head>
  <body>
    
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand menu-icon" href="#"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav me-auto mb-2 mb-md-0">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/main.php">Main</a>
            </li>
          <li class="nav-item">
            <a class="nav-link" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/board.php">아이디어</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/notice.php">공고정보</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/commu.php">소통</a>
          </li>
        </ul>
        <form class="d-flex">
          <button class="logout-button"type="button" onclick="location.href='index.php'">Logout</button>
        </form>
      </div>
    </div>
  </nav>
</header>

 

<main>

  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4"></button>
    </div>

    <div class="carousel-inner">

      <div class="carousel-item active">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="true">  
          <rect width="100%" height="100%" fill="#024152"/>
            <image href="assets/img/001.png" class="banner" height="100%" width="100%"/>
        </svg>
        <div class="container">
          <div class="carousel-caption text-start">
          </div>
        </div>
      </div>

      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#107F93"/>
          <a href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/board.php">
            <image   href="assets/img/002.png" class="banner" height="100%" width="100%"/>
          </a>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#C3BB93"/>
          <a href="http://localhost/%EC%B7%A8%EC%97%85%EC%95%84%EC%9D%B4%EB%94%94%EC%96%B4%EA%B3%B5%EC%9C%A0%ED%94%8C%EB%9E%AB%ED%8F%BC/bootstrap-5.1.3-examples/oasis/notice.php">
            <image   href="assets/img/003.png" class="banner" height="100%" width="100%"/>
          </a>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#FFDA77"/>
          <a href="http://localhost/%EC%B7%A8%EC%97%85%EC%95%84%EC%9D%B4%EB%94%94%EC%96%B4%EA%B3%B5%EC%9C%A0%ED%94%8C%EB%9E%AB%ED%8F%BC/bootstrap-5.1.3-examples/oasis/commu.php">
            <image   href="assets/img/004.png" class="banner" height="100%" width="100%"/>
          </a>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>


  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

<div class="container marketing">
    <!--홈페이지 앞면 최고조회수 게시글 2개 -->
    <div class="row mb-2">
        <div class="col-md-6">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                <div class="col p-4 d-flex flex-column position-static">
                    <?php
                        $conn = mysqli_connect('unilab.kro.kr', 'user', 'password', 'post', 7676);
                        $sql = "SELECT * FROM post_table WHERE post_id=1";
                        $result = mysqli_query($conn, $sql);
                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="card-body p-4">
                        <div class="text-center">
                            <!-- idea title-->
                            <h5 class="fw-bolder">
                                <a href="post.php?id=<?php echo $row['post_id']?>">
                                    <?php
                                    echo $row["post_title"];
                                    $_SESSION['id'] = $row["post_id"];
                                    ?>
                                </a>
                            </h5>
                            <!-- idea name-->
                            <p><?php echo $row["author"];?></p>
                            <p><?php echo $row["post_date"];?></p>
                            <p><?php echo $row["oneline"];?></p>
                            <p><?php echo $row["age"];?></p>
                        </div>
                    </div>
                </div>
                <div class="col-auto d-none d-lg-block">
                    <svg class="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text>
                        <image   href="<?php echo $row["img"];?>" class="banner" height="100%" width="100%"/>
                    </svg>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            mysqli_close($conn);
        }
        ?>
        <div class="col-md-6">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                <div class="col p-4 d-flex flex-column position-static">
                    <?php
                        $conn = mysqli_connect('unilab.kro.kr', 'user', 'password', 'post', 7676);
                        $sql = "SELECT * FROM post_table WHERE post_id=2";
                        $result = mysqli_query($conn, $sql);
                        if (mysqli_num_rows($result) > 0) {
                            while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="card-body p-4">
                        <div class="text-center">
                            <!-- idea title-->
                            <h5 class="fw-bolder">
                                <a href="post.php?id=<?php echo $row['post_id']?>">
                                    <?php
                                    echo $row["post_title"];
                                    $_SESSION['id'] = $row["post_id"];
                                    ?>
                                </a>
                            </h5>
                            <!-- idea name-->
                            <p><?php echo $row["author"];?></p>
                            <p><?php echo $row["post_date"];?></p>
                            <p><?php echo $row["oneline"];?></p>
                            <p><?php echo $row["age"];?></p>
                        </div>
                    </div>
                </div>
                <div class="col-auto d-none d-lg-block">
                    <svg class="bd-placeholder-img" width="200" height="250" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">Thumbnail</text>
                        <image   href="<?php echo $row["img"];?>" class="banner" height="100%" width="100%"/>
                    </svg>
                </div>
            </div>
        </div>
    </div>
    <?php
            }
        } else {
            mysqli_close($conn);
        }
    ?>
</div><!-- /.container -->


  <!-- FOOTER -->
  <footer class="container">
    <p class="float-end"><a href="#">Back to top</a></p>
    <p>&copy; 2022 07 21 Oasis, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>