<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Oasis Hackthon</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="oasis.css" rel="stylesheet">
  </head>
  <body>
<?php
$conn = mysqli_connect('unilab.kro.kr', 'user', 'password', 'post', 7676);
$event_id = $_GET['id'];
$sql = "SELECT * FROM event_table WHERE event_id = ".$event_id;
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($result)) {
?>
    <header>
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav me-auto mb-2 mb-md-0">
            <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/main.php">Main</a>
                </li>
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/board.php">아이디어</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/notice.php">공고정보</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/%ec%b7%a8%ec%97%85%ec%95%84%ec%9d%b4%eb%94%94%ec%96%b4%ea%b3%b5%ec%9c%a0%ed%94%8c%eb%9e%ab%ed%8f%bc/bootstrap-5.1.3-examples/oasis/commu.php">소통</a>
              </li>
            </ul>
            <form class="d-flex">
              <button class="logout-button"type="button" onclick="location.href='index.php'">Logout</button>
            </form>
          </div>
        </div>
      </nav>
    </header>
    
    

 

<main>

  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4"></button>
    </div>

    <div class="carousel-inner">

      <div class="carousel-item active">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="true">  
          <rect width="100%" height="100%" fill="#024152"/>
          <image   href="assets/img/001.png" class="banner" height="100%" width="100%"/>
        </svg>
        <div class="container">
          <div class="carousel-caption text-start">
          </div>
        </div>
      </div>

      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#107F93"/>
          <image   href="assets/img/002.png" class="banner" height="100%" width="100%"/>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#C3BB93"/>
          <image   href="assets/img/003.png" class="banner" height="100%" width="100%"/>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          <rect width="100%" height="100%" fill="#FFDA77"/>
          <image   href="assets/img/004.png" class="banner" height="100%" width="100%"/>
        </svg>

        <div class="container">
          <div class="carousel-caption text-end">
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  <div class="row g-5">
    <div class="col-md-8">
        <div class="centered">
      <h3 class="pb-4 mb-4 fst-italic border-bottom">
        <?php
          echo $row['event_title'];
        ?>
      </h3>
      <article class="blog-post">
        <p class="blog-post-meta"><?php echo $row['event_date'];?></p>
        <p><?php echo $row['event_article']; }?></p>
      </article>
</div>
    </div>
  </div>
</main>

<script>

/**
*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
/*
var disqus_config = function () {
this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
};
*/
(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = 'https://web1-2.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

  </p>
</body>

  <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

<footer class="blog-footer">
  <p>Blog template built for <a href="https://getbootstrap.com/">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
  <p>
    <a href="#">Back to top</a>
  </p>
</footer>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
    
  </body>
</html>
